//
//  RunCmdModel.swift
//  RunCmdModel
//
//  Created by yiming on 2021/8/21.
//

import UIKit

struct RunCmdModel: Convertible {
    var path: String = ""
    var args: [String] = []
}
